package P1;

public class Farm {

	private double availableFood;	
	Animal[] animals = {new Chicken(),new Cow(),new Llama(),new Llama()};
	
	public Farm() {
		setAvailableFood(1000);
	}
	public void makeNoise() {
		for (Animal ani : animals) {
			ani.sound();
		}
	}
	public void feedAnimals() {
		for (Animal ani : animals) {
			setAvailableFood(getAvailableFood() - ani.eat());
			if (ani.getMealAmount() > getAvailableFood()) {
				System.out.println("There isn't enough food");
			}
		}
	}

	public double getAvailableFood() {
		return availableFood;
	}
	public void setAvailableFood(double availableFood) {
		this.availableFood = availableFood;	
	}
	public Animal[] getAnimals() {
		return animals;
	}
}

